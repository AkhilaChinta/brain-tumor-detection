 # Brain Tumor Detection using AI

 This project aims at detecting brain tumor detection using MRI scans of brain. We initially fed the model with set of MRI scan images of the brain with and without having tumor to train the model. The model learns on how to differentiate using several libraries. 

 The project is built on [Kaggle](https://kaggle.com) and the source code with output can be seen at [Kaggle](https://www.kaggle.com/anilreddya/brain-tumor-detection)
 
 To run this projecr on kaggle, the project needs to be imported on the kaggle platform and make path changes to dataset accordingly. Omce the prject is imported click on the run all button or run each piece of code individually by clicking the run button beside each piece of code. Once the project is successfully launched, the console which will be at the bottom of the screen will give the output showing up the images with brain tumor and the accuracy of the model which is built. 

 Also this project can be run on google colab using the same way as kaggle.

 
